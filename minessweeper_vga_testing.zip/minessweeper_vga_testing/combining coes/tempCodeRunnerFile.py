ined_coe(base_data, r_map, g_map, b_map)
